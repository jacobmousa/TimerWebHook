using Microsoft.AspNetCore.Mvc;
using TimerWebHook.Logic;
using TimerWebHook.Logic.Model;

namespace TimerWebHook.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TimerController : ControllerBase
    {
        private static readonly TimerManager timerManager = new TimerManager();

        [HttpPost]
        [Route("setTimer")]
        public TimerResponse SetTimer([FromBody]TimerSet data)
        {
            int totalSecond = data.Hours * 60 + data.Minutes * 60 + data.Seconds;
            var timerAdded = timerManager.AddTimer(() => TimerCallback(), totalSecond,data.WebhookUrl); // 60 seconds interval
            TimerResponse timerResponse = new TimerResponse(timerAdded.Id, GetTimeLeft(timerAdded.executeTime));
            return timerResponse;
        }

        [HttpGet]
        [Route("getTimer/{id}")]
        public TimerResponse GetTimer(Guid id)
        {

            var timerItem = timerManager.GetTimer(id);

            TimerResponse timerResponse = new TimerResponse(id, GetTimeLeft(timerItem.executeTime));
            return timerResponse;
        }


        [HttpGet]
        [Route("list/{status}")]
        public TimerListResponse List(string status)
        {
            //List<TimerItem> result = TimerManager.GetList(status);

            TimerListResponse timerResponse = new TimerListResponse();
            timerResponse.pageNumber = 1;
            timerResponse.pageSize = 100;

            //TimerListItemResponse[] items  = new TimerListItemResponse;
            /*foreach(resultItem in result)
            {

            }*/

            return timerResponse;
        }


        private static int GetTimeLeft(TimeSpan executeTime)
        {
            return (int)(executeTime - DateTime.Now.TimeOfDay).TotalSeconds;
        }

        private void TimerCallback()
        {
            // Your code to execute after the specified interval
            // This will be called every 60 seconds in the example
            Console.WriteLine("Timer callback executed!");
        }

        /*[Route("api/timer/list")]
        public IHttpActionResult GetTimerList()
        {
            var timerList = timerManager.GetTimers();
            return Ok(timerList);
        }*/
    }
}
