﻿namespace TimerWebHook.Logic.Model
{
    public class TimerListResponse
    {
        public int pageNumber { get; set; }
        public int pageSize { get; set; }

        public TimerListItemResponse[] items;

    }

    public class TimerListItemResponse 
    {
        public int id  { get; set; }
        public DateTime dateCreated { get; set; }
        public string webhookUrl { get; set; }
        public string status { get; set; }

    }

}
