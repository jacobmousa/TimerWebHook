﻿using TimerWebHook.Logic.Model;

namespace TimerWebHook.Logic
{
    public class TimerManager
    {
        //Persist it in Database/file
        public readonly List<TimerItem> timers = new List<TimerItem>();

        public TimerItem AddTimer(Action callback, int intervalInSeconds,string webhookUrl)
        {

            TimeSpan executeTime = TimeSpan.FromSeconds(intervalInSeconds);
            var timer = new Timer(
                state => callback.Invoke(),
                null, TimeSpan.Zero,
                executeTime);

            TimerItem item = new TimerItem()
            {
                TimerValue = timer,
                Id = Guid.NewGuid(),
                executeTime = DateTime.Now.TimeOfDay.Add(executeTime)//,
                //webHookUrl = webhookUrl
            };
            timers.Add(item);

            return (item);
        }

        public TimerItem GetTimer(Guid id)
        {
            var result = timers.Where(a => a.Id == id);
            return result.FirstOrDefault();
        }

        public List<TimerItem> GetTimers()
        {
            return timers;
        }

        //public List<TimerItem> GetList(string status)
        //{
        //    var result = timers.Where(a=>a.Status == status).ToList();
        //    return (result);
        //}

        // Add more methods for removing, stopping, or managing timers as needed
    }





}
